#ifndef APPLYCARSTATION_H
#define APPLYCARSTATION_H

#include <QWidget>
#include <QSqlTableModel>
#include <QMessageBox>
#include <QSqlRecord>
#include <QDebug>
#include <QButtonGroup>

namespace Ui {
class ApplyCarStation;
}

class ApplyCarStation : public QWidget
{
    Q_OBJECT

public:
    explicit ApplyCarStation(QWidget *parent = 0);
    ~ApplyCarStation();

private slots:
    void on_applyCarStationConfirmBtn_clicked();

    void on_applyCarStationReturnBtn_clicked();

private:
    Ui::ApplyCarStation *ui;
    QSqlTableModel *myCarStationModel;
    QButtonGroup *typeRadioGroup;
    QButtonGroup *largeRadioGroup;
    QButtonGroup *electRadioGroup;
    //QButtonGroup *rentRadioGRroup;

};

#endif // APPLYCARSTATION_H
