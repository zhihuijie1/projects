#include "setowner.h"
#include "ui_setowner.h"

SetOwner::SetOwner(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SetOwner)
{
    ui->setupUi(this);
    showOwnerTalbe = new QSqlTableModel(this);
    showOwnerTalbe->setEditStrategy(QSqlTableModel::OnManualSubmit);
    showOwnerTalbe->setTable("houseowner");
    showOwnerTalbe->select();
    ui->tableView->setModel(showOwnerTalbe);
}

SetOwner::~SetOwner()
{
    delete ui;
}
