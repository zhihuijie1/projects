#include "houseinfo.h"
#include "ui_houseinfo.h"

HouseInfo::HouseInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::HouseInfo)
{
    ui->setupUi(this);
    //设置model实现与数据库交互
    houseInfoModel=new QSqlTableModel(this);
    houseInfoModel->setTable("house");
    houseInfoModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    houseInfoModel->removeColumns(5,5);/*?*/
    //connect(this,SIGNAL(EmitDataChanged()),,SLOT(refreshTableViewSlot()));
}

HouseInfo::~HouseInfo()
{
    delete ui;
}

bool HouseInfo::judgeEmpty()
{
    if(ui->houseOwnerLineEdit->text().isEmpty())
    {
        QMessageBox::warning(this,"警告","业主姓名不能为空",QMessageBox::Yes);
        return false;
    }
    else if(ui->houseAddressLineEdit->text().isEmpty())
    {
        QMessageBox::warning(this,"警告","房屋信息不能为空",QMessageBox::Yes);
        return false;
    }
    else
        return true;
}
void HouseInfo::clearAll()
{
    ui->houseOwnerLineEdit->clear();
    ui->houseAddressLineEdit->clear();
    ui->houseAreaLineEdit->clear();
    ui->houseTypeLineEdit->clear();
}


void HouseInfo::on_houseInfoConfirmBtn_clicked()
{
    if(!this->judgeEmpty())
        return;
    houseInfoModel->select();
    int i;
    for(i=0;i<houseInfoModel->rowCount();i++)
    {
        if(houseInfoModel->data(houseInfoModel->index(i,0)).toString()==ui->houseAddressLineEdit->text())
        {
            break;
        }
    }
    if(i!=houseInfoModel->rowCount())
    {
        QMessageBox::information(this,"提示","该房屋已经存在",QMessageBox::Yes);
        this->clearAll();
        return;
    }
    QSqlRecord record=houseInfoModel->record();
    record.setValue("houseowner",ui->houseOwnerLineEdit->text());
    record.setValue("houseaddress",ui->houseAddressLineEdit->text());
    record.setValue("housetype",ui->houseTypeLineEdit->text());
    record.setValue("housearea",ui->houseAreaLineEdit->text());

    houseInfoModel->insertRecord(-1,record);
    if(houseInfoModel->submitAll())
    {
        QMessageBox::information(this,"提示","业主房屋信息添加成功",QMessageBox::Yes);
        this->clearAll();
    }
}

void HouseInfo::on_houserInfoReturnBtn_clicked()
{
    if(ui->houseOwnerLineEdit->text().isEmpty()&&ui->houseTypeLineEdit->text().isEmpty()&&
       ui->houseAddressLineEdit->text().isEmpty()&&ui->houseAddressLineEdit->text().isEmpty())
    {
        //emit EmitWorkerChanged();
        this->hide();
         qDebug("addworker");
        return;

    }
    if(QMessageBox::question(this,"提示","尚未保存，是否退出",QMessageBox::Yes|QMessageBox::No)==QMessageBox::Yes)
    {        
        this->hide();
        houseInfoModel->select();       
    }
}
