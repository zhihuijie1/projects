#ifndef ISSUEINFO_H
#define ISSUEINFO_H

#include <QWidget>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QMessageBox>
#include <QDateTime>
#include <QDebug>



namespace Ui {
class IssueInfo;
}

class IssueInfo : public QWidget
{
    Q_OBJECT

public:
    explicit IssueInfo(QWidget *parent = 0);
    ~IssueInfo();
    void setUserName(const QString strName);
private slots:
    void on_issueConfirmBtn_clicked();

    void on_issueReturnBtn_clicked();

private:
    Ui::IssueInfo *ui;
    QSqlTableModel *issueModel;
    QString m_strUserName;
};

#endif // ISSUEINFO_H
