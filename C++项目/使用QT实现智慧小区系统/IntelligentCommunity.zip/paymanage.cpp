#include "paymanage.h"
#include "ui_paymanage.h"
#include "ownerpayself.h"

PayManage::PayManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PayManage)
{
    ui->setupUi(this);

    payModel = new QSqlTableModel(this);
    payModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    payModel->setTable("priceRecord");
    payModel->select();
    payModel->setHeaderData(0,Qt::Horizontal,tr("缴费人"));
    payModel->setHeaderData(1,Qt::Horizontal,tr("缴费类型"));
    payModel->setHeaderData(2,Qt::Horizontal,tr("缴费金额"));
    payModel->setHeaderData(3,Qt::Horizontal,tr("缴费时间"));
    ui->payTableView->setModel(payModel);

    payStatusGroup=new QButtonGroup(this);
    payStatusGroup->addButton(ui->payedRadioButton,0);
    payStatusGroup->addButton(ui->payRadioButton,1);
    ui->payRadioButton->setChecked(true);
}

PayManage::~PayManage()
{
    delete ui;
}

void PayManage::on_squreBtn_clicked()
{
    if(ui->ownerNameLineEdit->text().isEmpty())
    {
        if(payStatusGroup->checkedId()== 0)
        {
            payModel->setFilter("type='车位租金'");
        }
        else
        {
             payModel->setFilter("type='物业费'");
        }
    }
    else
    {
        if(payStatusGroup->checkedId()==0)
        {
            payModel->setFilter(QString("ownername= '%1'and type='车位租金'")
                                .arg(ui->ownerNameLineEdit->text()));
        }
        else
        {
            //----------------修改------------------
             payModel->setFilter(QString("ownername= '%1'and type='物业费'")
                                 .arg(ui->ownerNameLineEdit->text()));
        }
    }
    payModel->select();
    ui->payTableView->setModel(payModel);

}

void PayManage::on_payConfirmBtn_clicked()
{

    payModel->database().transaction();
    if(payModel->submitAll())
    {
        payModel->database().commit();
    }
    else
    {
        payModel->database().rollback();
        QMessageBox::warning(this,tr("tabalModel"),
                             tr("数据库错误:% 1").arg(payModel->lastError().text()));
    }
}

void PayManage::on_pushButton_clicked()
{
    ownerPaySelf *p = new ownerPaySelf;
    p->show();
}
