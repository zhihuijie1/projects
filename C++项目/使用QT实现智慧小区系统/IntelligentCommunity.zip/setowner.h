#ifndef SETOWNER_H
#define SETOWNER_H

#include <QWidget>
#include <QSqlTableModel>


namespace Ui {
class SetOwner;
}

class SetOwner : public QWidget
{
    Q_OBJECT

public:
    explicit SetOwner(QWidget *parent = 0);
    ~SetOwner();

private:
    Ui::SetOwner *ui;
    QSqlTableModel *showOwnerTalbe;
};

#endif // SETOWNER_H
