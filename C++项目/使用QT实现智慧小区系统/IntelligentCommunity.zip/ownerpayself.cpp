#include <QSqlTableModel>
#include <QSqlRecord>
#include <QMessageBox>
#include <QDateTime>
#include <QSqlQuery>
#include <QDebug>
#include "ownerpayself.h"
#include "ui_ownerpayself.h"

ownerPaySelf::ownerPaySelf(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ownerPaySelf)
{
    ui->setupUi(this);
    QRegExp regx("[0-9]+$");
    QValidator* validator = new QRegExpValidator(regx);
    ui->lineEdit->setValidator(validator);
}

ownerPaySelf::~ownerPaySelf()
{
    delete ui;
}

void ownerPaySelf::on_pushButton_clicked()
{
    //trimmed：去除空格
    QString strValue = ui->lineEdit->text().trimmed();

    if(strValue.isEmpty()) {
        QMessageBox::warning(this, tr("提示"), tr("请输入缴费金额"));
        return ;
    }
    //下拉菜单
    QString strType = ui->comboBox->currentText();
    QSqlTableModel tableModel;
    tableModel.setTable("priceRecord");
    tableModel.select();
    //模型中第一行的数据
    QSqlRecord record = tableModel.record(0);
    record.setValue("ownername", ui->lineEdit_2->text().trimmed());
    record.setValue("type", strType);
    record.setValue("price", strValue);

    QDateTime time = QDateTime::currentDateTime();
    QString str = time.toString("yyyy-MM-dd hh:mm:ss");
    record.setValue("time", str);

    tableModel.insertRecord(-1, record);
    // ------------------------------------ 修改 ----------------------------------
    if(tableModel.submitAll())
    {
        if(updateState(ui->comboBox->currentIndex()))
        {
                QMessageBox::information(this,"提示","车位缴费成功",QMessageBox::Yes);
                ui->lineEdit->clear();
        }
        else{
                QMessageBox::information(this,"提示","物业费缴费成功",QMessageBox::Yes);
                ui->lineEdit->clear();
        }
     }else{
        QMessageBox::information(this,"提示","缴费出错，请重新缴费",QMessageBox::Yes);
     }
}
void ownerPaySelf::on_pushButton_2_clicked()
{
    this->close();
}
bool  ownerPaySelf::updateState(int nType)
{
    if(0 ==  nType)
    {
        // 车位缴费，更新车位缴费状态
        QString strSql = QString("update carstation set paystate = '已缴费' \
                            where ownername = '%1'").arg(this->windowTitle().trimmed());
        QSqlQuery query;
        return query.exec(strSql);

    }
    else
    {
        return false;//其他缴费
    }
}
