#ifndef PRICEMANAGE_H
#define PRICEMANAGE_H

#include <QWidget>
#include <QSqlTableModel>
#include <QMessageBox>
#include <QSqlRecord>
#include <QDebug>

namespace Ui {
class PriceManage;
}

class PriceManage : public QWidget
{
    Q_OBJECT

public:
    explicit PriceManage(QWidget *parent = 0);
    ~PriceManage();

private slots:
    void on_priceConfirmBtn_clicked();

    void on_priceReturnBtn_clicked();

private:
    Ui::PriceManage *ui;
    QSqlTableModel *priceModel;

};

#endif // PRICEMANAGE_H
