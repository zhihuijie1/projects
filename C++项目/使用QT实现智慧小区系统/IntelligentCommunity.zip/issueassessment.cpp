#include <QMessageBox>
#include <QSqlQuery>
#include "issueassessment.h"
#include "ui_issueassessment.h"

issueAssessment::issueAssessment(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::issueAssessment)
{
    ui->setupUi(this);
    m_strIndex = "";
}

issueAssessment::~issueAssessment()
{
    delete ui;
}

void issueAssessment::on_pushButton_2_clicked()
{
    if(m_strIndex.isEmpty())
    {
        QMessageBox::warning(this, "提示", "请在上一个界面选中要评论的记录");
        return;
    }
    QString strInfo = ui->textEdit->toPlainText();
    if(strInfo.isEmpty())
    {
        QMessageBox::warning(this, "提示", "请填写评价");
        return;
    }
    QSqlQuery query;
    //-------------------------------------------------修改---------------------------------------------
    QString strSql = QString("update errorinfo set assessment = '%1' where errornum = '%2' ")
            .arg(strInfo).arg(m_strIndex);
    if(query.exec(strSql))
    {
        QMessageBox::warning(this, "提示", "评价成功");
        this->close();
    }
    else
    {
        QMessageBox::warning(this, "提示", "评价失败，请重新输入");
    }
    return;

}
void issueAssessment::setMessageIndex(QString strIndex)
{
    m_strIndex = strIndex;
}
void issueAssessment::on_pushButton_clicked()
{
    this->close();
}
