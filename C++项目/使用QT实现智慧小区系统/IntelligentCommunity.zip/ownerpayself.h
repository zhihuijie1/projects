#ifndef OWNERPAYSELF_H
#define OWNERPAYSELF_H

#include <QWidget>

namespace Ui {
class ownerPaySelf;
}

class ownerPaySelf : public QWidget
{
    Q_OBJECT

public:
    explicit ownerPaySelf(QWidget *parent = 0);
    ~ownerPaySelf();
    bool  updateState(int nType);
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::ownerPaySelf *ui;
};

#endif // OWNERPAYSELF_H
