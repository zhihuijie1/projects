#ifndef MANAGERMANAGE_H
#define MANAGERMANAGE_H

#include <QMainWindow>
#include <QToolBar>
#include <QMenu>
#include <QDebug>
#include <QAction>
#include <QTableView>
#include <QSqlTableModel>

#include <QSqlRecord>
#include <QString>
#include <QSize>
#include <QSqlError>

#include "workerinfo.h"


namespace Ui {
class ManagerManage;
}

class ManagerManage : public QMainWindow
{
    Q_OBJECT

public:
    explicit ManagerManage(QWidget *parent = 0);
    ~ManagerManage();

private:
    Ui::ManagerManage *ui;

    //文本框
    //QPlainTextEdit *textEdit;

    //表预览、SQL模型
    QTableView *tableView;
    QSqlTableModel *model;

    //定义两个菜单：人事管理和系统参数菜单
    QMenu *workerManageMenu;
    QMenu *systemParameterMenu;

    //定义两个工具栏：人事管理和系统参数工具栏
    QToolBar *workerManageToolBar;
    QToolBar *systemParameterToolBar;

    //定义了人事管理菜下拉菜单：查看、添加、修改、删除工作人员
    QAction *showWorkerAct;
    QAction *addWorkerAct;
    QAction *alterWorkerAct;
    QAction *delWorkerAct;

    //请假审批、查看出勤
    QAction *freeConfirmAct;
    QAction *freeApproveAct;
    QAction *queryrAttendAct;

    //定义系统参数菜单的下拉菜单：参数设置和系统初始化
    QAction *setParameterAct;
    QAction *initSystemAct;

    //工作人员信息
    WorkerInfo *workerInfo;
    int status;

    //动作、菜单、菜单栏
    void createMenus();
    void createActions();
    void createToolBars();
    void alterCurRow();
    void setTableHead();


signals:
    //void EmitToManagerManage();
    void EmitWorkerChanged();

private slots:
    void test();
    void showWorkerSlot();
    void addWorkerSlot();
    void alterWorkerSlot();
    void delWorkerSlot();

    void freeWorkerSlot();
    void freeConfirmSlot();
    void attendWorkerSlot();
    void refreshTableViewSlot();
    void initSystemSlot();
};

#endif // MANAGERMANAGE_H
