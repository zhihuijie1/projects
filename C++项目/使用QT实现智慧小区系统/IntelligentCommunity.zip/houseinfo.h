#ifndef HOUSEINFO_H
#define HOUSEINFO_H

#include <QWidget>
#include <QSqlTableModel>
#include <QMessageBox>
#include <QSqlRecord>
#include <QDebug>

namespace Ui {
class HouseInfo;
}

class HouseInfo : public QWidget
{
    Q_OBJECT

public:
    explicit HouseInfo(QWidget *parent = 0);
    ~HouseInfo();

private slots:
    void on_houseInfoConfirmBtn_clicked();

    void on_houserInfoReturnBtn_clicked();

private:
    Ui::HouseInfo *ui;

    QSqlTableModel *houseInfoModel;

    bool judgeEmpty();
    void clearAll();

};

#endif // HOUSEINFO_H
