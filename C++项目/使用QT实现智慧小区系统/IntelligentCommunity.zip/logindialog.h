#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>
#include <QMessageBox>
#include <QButtonGroup>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QDebug>
#include "managermanage.h"
#include "workermanage.h"
#include "ownermanage.h"

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = 0);
    ~LoginDialog();
    void clearAll();
    bool judgeEmpty();

private:
    Ui::LoginDialog *ui;
    ManagerManage *manager;
    WorkerManage *worker;
    OwnerManage *owner;
    QButtonGroup *radioGroup;
    QSqlTableModel *model;

signals:
    void toManagerManage(QString,QString);
    void toWorkerManage(QString,QString);
    void toOwnnerManage(QString,QString);

private slots:
    void exitbtnSlot();
    void loginbtnSlot();

};

#endif // LOGINDIALOG_H
