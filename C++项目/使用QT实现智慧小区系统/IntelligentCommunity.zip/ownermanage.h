#ifndef OWNERMANAGE_H
#define OWNERMANAGE_H

#include <QMainWindow>
#include <QTableView>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QSqlQueryModel>

#include "issueinfo.h"
#include "applycarstation.h"

namespace Ui {
class OwnerManage;
}

class OwnerManage : public QMainWindow
{
    Q_OBJECT

public:
    explicit OwnerManage(QWidget *parent = 0);
    ~OwnerManage();

private:
    Ui::OwnerManage *ui;
    //表预览
    QTableView *ownerTableView;
    QSqlQueryModel *ownerQueryModel;
    QSqlTableModel *ownerModel;
    IssueInfo *issue;
    ApplyCarStation *applyCarStation;
    int ownerState;

signals:
    //void EmitToManagerManage();
    void EmitOwnerChanged();

private slots:

    void on_applyCarStationAct_triggered();
    void on_showcCarStationAct_triggered();
    void on_payAct_triggered();
    void on_issueReportAct_triggered();
    void on_issueProcessAct_triggered();
    void on_issueEvaluateAct_triggered();
    void on_payShowAct_triggered();
};

#endif // OWNERMANAGE_H
