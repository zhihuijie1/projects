#include "applycarstation.h"
#include "ui_applycarstation.h"

ApplyCarStation::ApplyCarStation(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ApplyCarStation)
{
    ui->setupUi(this);
    typeRadioGroup=new QButtonGroup(this);
    typeRadioGroup->addButton(ui->carStationUpRadioBtn,0);
    typeRadioGroup->addButton(ui->carStationDownRadioBtn,1);
    ui->carStationUpRadioBtn->setChecked(true);

    largeRadioGroup=new QButtonGroup(this);
    largeRadioGroup->addButton(ui->carStationLargeRadioBtn,0);
    largeRadioGroup->addButton(ui->carStationSmallRadioBtn,1);
    ui->carStationLargeRadioBtn->setChecked(true);

    electRadioGroup=new QButtonGroup(this);
    electRadioGroup->addButton(ui->carStationEnableRadioBtn,0);
    electRadioGroup->addButton(ui->carStationDisableRadioBtn,1);
    ui->carStationDisableRadioBtn->setChecked(true);

    myCarStationModel=new QSqlTableModel(this);
    myCarStationModel->setTable("carstation");
    myCarStationModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
}

ApplyCarStation::~ApplyCarStation()
{
    delete ui;
}

void ApplyCarStation::on_applyCarStationConfirmBtn_clicked()
{
    if(ui->carNumLineEdit->text().isEmpty()&&ui->nameLineEdit->text().isEmpty())
        return;
    myCarStationModel->setTable("carstation");
    QString strFilter = QString("type = %1 and large = %2\
                                 and electric = %3 and ownername = ''\
                                 or ownername is null")
                        .arg(typeRadioGroup->checkedId())
                        .arg(largeRadioGroup->checkedId())
                        .arg(electRadioGroup->checkedId());
    qDebug() << "strFilter: " << strFilter;
    myCarStationModel->setFilter(strFilter);
    myCarStationModel->select();
    if(0 == myCarStationModel->rowCount())
    {
        QMessageBox::information(this,"提示","没有查询到符合条件的车位",QMessageBox::Yes);
        return;
    }
    QSqlRecord record=myCarStationModel->record(0);

    record.setValue("ownername",ui->nameLineEdit->text());
    record.setValue("carnum",ui->carNumLineEdit->text());
    record.setValue("paystate","未缴费");
    myCarStationModel->setRecord(0, record);
    if(myCarStationModel->submitAll())
    {
        QMessageBox::information(this,"提示","申请成功",QMessageBox::Yes);
        ui->nameLineEdit->clear();
        ui->carNumLineEdit->clear();
        this->close();
    }
    else
    {
        QMessageBox::information(this,"提示","没有查询到符合条件的车位",QMessageBox::Yes);
    }
}

void ApplyCarStation::on_applyCarStationReturnBtn_clicked()
{
    this->close();
}
