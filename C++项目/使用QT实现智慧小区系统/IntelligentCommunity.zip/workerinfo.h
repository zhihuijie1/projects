#ifndef WORKERINFO_H
#define WORKERINFO_H

#include <QWidget>
#include <QDebug>
#include <QMessageBox>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QButtonGroup>
//#include "managermanage.h"

namespace Ui {
class WorkerInfo;
}

class WorkerInfo : public QWidget
{
    Q_OBJECT

public:
    explicit WorkerInfo(QWidget *parent = 0);
    ~WorkerInfo();


private slots:
    void on_AddActBtn_clicked();

    void on_ReturnBtn_clicked();

signals:
    void EmitWorkerChanged();

private:
    Ui::WorkerInfo *ui;
    QSqlTableModel *model;
    QButtonGroup *isManagerRadioGroup;

    bool judgeEmpty();
    void clearAll();
};

#endif // WORKERINFO_H
