#ifndef WORKERFREE_H
#define WORKERFREE_H

#include <QWidget>
#include <QSqlQueryModel>
#include <QSqlTableModel>
#include <QMessageBox>
#include <QSqlRecord>
#include <QDebug>
#include <QDateTime>
#include <QString>
#include <QButtonGroup>

namespace Ui {
class WorkerFree;
}

class WorkerFree : public QWidget
{
    Q_OBJECT

public:
    explicit WorkerFree(QWidget *parent = 0);
    ~WorkerFree();

private slots:
    void on_workerFreeBtn_clicked();

    void on_workerFreeReturnBtn_clicked();

    void on_freeRadioButton_clicked();

    void on_attendRadioButton_clicked();

private:
    Ui::WorkerFree *ui;

    QSqlTableModel *workerFreeModel;
    QButtonGroup *freeInfoRadioGroup;

    bool judgeEmpty();
    void clearAll();
};

#endif // WORKERFREE_H
