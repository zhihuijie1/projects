#include "ownermanage.h"
#include "ui_ownermanage.h"
#include "ownerpayself.h"
#include "issueassessment.h"

OwnerManage::OwnerManage(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::OwnerManage)
{
    ui->setupUi(this);
    ui->toolBar->setIconSize(QSize(50,50));

    //创建一个文本编辑器
    ownerTableView=new QTableView;
    //textEdit=new QPlainTextEdit;

    //设置文本编辑器为中心部件
    setCentralWidget(ownerTableView);

    //设置model实现与数据库交互
    ownerModel=new QSqlTableModel(this);
    ownerQueryModel = new QSqlQueryModel;
    ownerModel->setTable("owner");
    ownerModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    ownerModel->removeColumns(5,5);/*?*/
}

OwnerManage::~OwnerManage()
{
    delete ui;
}

void OwnerManage::on_applyCarStationAct_triggered()
{
    applyCarStation=new ApplyCarStation;
    applyCarStation->show();
}
// 显示我的车位信息
void OwnerManage::on_showcCarStationAct_triggered()
{
    ownerModel->setTable("carstation");
    QString strFilter = QString("ownername = '%1'").arg(this->windowTitle().trimmed());
    qDebug() << "strFilter:" << strFilter;
    ownerModel->setFilter(strFilter);
    ownerModel->select();
    ownerModel->setHeaderData(0,Qt::Horizontal,tr("车位号"));
    ownerModel->setHeaderData(1,Qt::Horizontal,tr("地上/地下"));
    ownerModel->setHeaderData(2,Qt::Horizontal,tr("大/小"));
    ownerModel->setHeaderData(3,Qt::Horizontal,tr("能否充电"));
    ownerModel->setHeaderData(4,Qt::Horizontal,tr("所属业主"));
    ownerModel->setHeaderData(5,Qt::Horizontal,tr("缴费状态"));
    ownerTableView->setModel(ownerModel);
}
// 自助缴费
void OwnerManage::on_payAct_triggered()
{
    ownerPaySelf *pPay = new ownerPaySelf();
    QString strOwner = this->windowTitle();
    pPay->setWindowTitle(strOwner);
    pPay->show();
}
//故障报修
void OwnerManage::on_issueReportAct_triggered()
{
    issue=new IssueInfo;
    issue->setUserName(this->windowTitle().trimmed());
    issue->show();
}
// 维修进度
void OwnerManage::on_issueProcessAct_triggered()
{
    ownerState = 2;
    QString strSql = QString("ownername = '%1'").arg(this->windowTitle().trimmed());
    ownerModel->setTable("errorinfo");
    ownerModel->setFilter(strSql);
    ownerModel->select();
    ownerModel->setHeaderData(0,Qt::Horizontal,tr("序号"));
    ownerModel->setHeaderData(1,Qt::Horizontal,tr("申请人"));
    ownerModel->setHeaderData(2,Qt::Horizontal,tr("故障描述"));
    ownerModel->setHeaderData(3,Qt::Horizontal,tr("申请时间"));
    ownerModel->setHeaderData(4,Qt::Horizontal,tr("维修进度"));
    ownerModel->setHeaderData(4,Qt::Horizontal,tr("维修评价"));
    ownerTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ownerTableView->setModel(ownerModel);
}
// 维修评价
void OwnerManage::on_issueEvaluateAct_triggered()
{
    if(2 ==  ownerState)
    {
        int n = ownerTableView->currentIndex().row();
        QString strInfo = ownerModel->record(n).value("errornum").toString();

        issueAssessment *p = new issueAssessment(this);
        p->setMessageIndex(strInfo);
        p->exec();

    }
    ownerModel->select();
}


void OwnerManage::on_payShowAct_triggered()
{
    ownerModel->setTable("priceRecord");
    QString strFilter = QString("ownername = '%1'").arg(this->windowTitle().trimmed());
    ownerModel->setFilter(strFilter);
    ownerModel->select();

    ownerModel->setHeaderData(0,Qt::Horizontal,tr("缴费人"));
    ownerModel->setHeaderData(1,Qt::Horizontal,tr("缴费类型"));
    ownerModel->setHeaderData(2,Qt::Horizontal,tr("缴费金额"));
    ownerModel->setHeaderData(3,Qt::Horizontal,tr("缴费时间"));
    ownerTableView->setModel(ownerModel);
}
