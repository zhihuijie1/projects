#include "issueinfo.h"
#include "ui_issueinfo.h"

IssueInfo::IssueInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::IssueInfo)
{
    ui->setupUi(this);

    issueModel=new QSqlTableModel(this);
    issueModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    m_strUserName = "";
}

IssueInfo::~IssueInfo()
{
    delete ui;
}
void IssueInfo::setUserName(const QString strName)
{
    m_strUserName = strName;
}
void IssueInfo::on_issueConfirmBtn_clicked()
{
    if(ui->issueReporterLineEdit->text().isEmpty()
            &&ui->issueReportMessTextEdit->toPlainText().isEmpty())
    {
        QMessageBox::warning(this,"警告","故障报修请填写完整",QMessageBox::Yes);
        return;
    }
    else
    {
         issueModel->setTable("errorinfo");
         issueModel->select();
         QSqlRecord record=issueModel->record();

         //--------------------------------------修改----------------------------------
         record.setValue("error",ui->issueReporterLineEdit->text());
         record.setValue("errorowner",ui->issueReporterLineEdit->text());
         record.setValue("errormess",ui->issueReportMessTextEdit->toPlainText());
         record.setValue("ownername",m_strUserName);
         QDateTime time = QDateTime::currentDateTime();
         QString str = time.toString("yyyy-MM-dd hh:mm:ss");
         record.setValue("errortime",str);
         record.setValue("errorState","申报");
         issueModel->insertRecord(-1,record);
         if(issueModel->submitAll())
         {
             QMessageBox::information(this,"提示","故障报修成功",QMessageBox::Yes);

         }
         else
         {
              QMessageBox::information(this,"提示","故障报修失败，请重新填写",QMessageBox::Yes);
         }
             this->close();
    }
}

void IssueInfo::on_issueReturnBtn_clicked()
{
    this->hide();
}
