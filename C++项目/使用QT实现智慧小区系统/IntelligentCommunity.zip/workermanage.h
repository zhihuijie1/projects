#ifndef WORKERMANAGE_H
#define WORKERMANAGE_H

#include <QMainWindow>
#include <QTableView>
#include <QSqlTableModel>
#include <QLabel>
#include <QDebug>
#include <QSqlError>
#include <QString>
#include "ownerinfo.h"
#include "houseinfo.h"
#include "carstationinfo.h"
#include "workerfree.h"
#include "setowner.h"
#include "pricemanage.h"
#include "paymanage.h"

namespace Ui {
class WorkerManage;
}

class WorkerManage : public QMainWindow
{
    Q_OBJECT

public:
    explicit WorkerManage(QWidget *parent = 0);
    ~WorkerManage();

private:
    Ui::WorkerManage *ui;

    QLabel *lable;
    QTableView *workerTableView;
    QSqlTableModel *workerModel;

    OwnerInfo *ownerInfo;
    HouseInfo *houseInfo;
    CarStationInfo *carStationInfo;
    WorkerFree *workFree;
    SetOwner *owner;
    PayManage *paymanage;
    PriceManage *pricemanage;
    int workerManageStatus;


    void delCurRow();
    void alterCurRow();
    void setTableHead();


signals:
    //void EmitToManagerManage();
    void EmitOwnerChanged();

private slots:

    void showOwnerSlot();
    void addOwnerSlot();
    void addHouseSlot();
    void alterOwnerSlot();
    void delOwnerSlot();

    void showCarStationSlot();
    void addCarStationSlot();
    void alterCarStationSlot();
    void delCarStationSlot();
    void carStationRentActSlot();
    //void houseInfoSlot();
    void priceManageSlot();
    void payInfoSlot();
    void paySlot();

    void issueShowSlot();
    void issueRepairSlot();

    void freeSlot();
    void freeConfirmSlot();
    void attendSlot();



    //void attendWorkerSlot();
    void refreshTableViewSlot();

};

#endif // WORKERMANAGE_H
