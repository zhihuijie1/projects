#ifndef ISSUEASSESSMENT_H
#define ISSUEASSESSMENT_H

#include <QWidget>
#include <QDialog>

namespace Ui {
class issueAssessment;
}

class issueAssessment : public QDialog
{
    Q_OBJECT

public:
    explicit issueAssessment(QWidget *parent = 0);
    ~issueAssessment();
    void setMessageIndex(QString strIndex);

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::issueAssessment *ui;
    QString m_strIndex;
};

#endif // ISSUEASSESSMENT_H
