#include <QMessageBox>
#include <QSqlQuery>
#include <QDebug>
#include "initsystem.h"
#include "ui_initsystem.h"

initSystem::initSystem(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::initSystem)
{
    ui->setupUi(this);
}

initSystem::~initSystem()
{
    delete ui;
}
// 初始化车位信息
void initSystem::on_btnCarInit_clicked()
{
    int ret = QMessageBox::warning(this, "提示", "确定是否要对系统进行初始化", QMessageBox::Yes | QMessageBox::No);
    if(QMessageBox::Yes == ret)
    {
        QSqlQuery query;
        QString strSql = "delete from carstation";
        query.exec(strSql);
    }
    else
    {
        qDebug() << "取消系统初始化";
    }
}
// 初始化故障维修记录
void initSystem::on_btnIssue_clicked()
{
    int ret = QMessageBox::warning(this, "提示", "确定是否要对系统进行初始化", QMessageBox::Yes | QMessageBox::No);
    if(QMessageBox::Yes == ret)
    {
        QSqlQuery query;
        QString strSql = "delete from errorinfo";
        query.exec(strSql);
    }
    else
    {
        qDebug() << "取消系统初始化";
    }
}
// 初始化收费标准
void initSystem::on_btnPrice_clicked()
{
    int ret = QMessageBox::warning(this, "提示", "确定是否要对收费标准进行初始化", QMessageBox::Yes | QMessageBox::No);
    if(QMessageBox::Yes == ret)
    {
        QSqlQuery query;
        QString strSql = "delete from price";
        query.exec(strSql);
    }
    else
    {
        qDebug() << "取消系统初始化";
    }
}
// 初始化收费记录
void initSystem::on_btnPriceRecord_clicked()
{
    int ret = QMessageBox::warning(this, "提示", "确定是否要对收费记录进行初始化", QMessageBox::Yes | QMessageBox::No);
    if(QMessageBox::Yes == ret)
    {
        QSqlQuery query;
        QString strSql = "delete from priceRecord";
        query.exec(strSql);
    }
    else
    {
        qDebug() << "取消系统初始化";
    }
}
// 初始化请假信息
void initSystem::on_btnFree_clicked()
{
    int ret = QMessageBox::warning(this, "提示", "确定是否要对请假信息进行初始化", QMessageBox::Yes | QMessageBox::No);
    if(QMessageBox::Yes == ret)
    {
        QSqlQuery query;
        QString strSql = "delete from workerattend";
        query.exec(strSql);
    }
    else
    {
        qDebug() << "取消系统初始化";
    }
}
