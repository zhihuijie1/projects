#include "logindialog.h"
#include "ui_logindialog.h"

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);

    radioGroup=new QButtonGroup(this);
    radioGroup->addButton(ui->managerRadio,0);
    radioGroup->addButton(ui->workerRadio,1);
    radioGroup->addButton(ui->ownerRadio,2);

    //连接信号与槽,登录button与退出button
    connect(ui->loginBtn,SIGNAL(clicked()),this,SLOT(loginbtnSlot()));
    connect(ui->exitBtn,SIGNAL(clicked()),this,SLOT(exitbtnSlot()));

}

LoginDialog::~LoginDialog()
{
    delete ui;
}

//登录
void LoginDialog::loginbtnSlot()
{
    //判断用户名和密码是否为空
    if(!this->judgeEmpty())
    {
        ui->passwordLine->clear();
        return;
    }

    qDebug() << "radioGroup->checkedId() :" << radioGroup->checkedId();
    //判断管理员登录
    if(radioGroup->checkedId()==0)
    {

        //判断管理员账户与密码
        QSqlQuery query;
        query.prepare("select * from worker where workernum=?");
        query.addBindValue(ui->userLine->text().trimmed());
        query.exec();
        if(query.next())
        {
           if (query.value(1).toString() == ui->passwordLine->text())
            {
              if(query.value(3).toString()=="否")
              {
                  QMessageBox::warning(this, tr("此用户非管理员"),
                                       tr("请选择合适权限用户登录"), QMessageBox::Ok);
                  return;
              }
               //创建管理员登录窗口
               manager=new ManagerManage;
               manager->show();
               this->hide();
               return;
            }
            else
            {
                QMessageBox::warning(this, tr("账号密码错误"),
                                     tr("请输入正确的账号密码再登录！"), QMessageBox::Ok);
                ui->userLine->clear();
                ui->passwordLine->clear();
                ui->userLine->setFocus();
            }
        }
        else
            QMessageBox::information(this,tr("提示"),tr("没有此账号！"),QMessageBox::Ok);
    }
    //判断是工作人员登录
    else if(radioGroup->checkedId()==1)
    {
        QSqlQuery query;
        query.prepare("select * from worker where workernum=?");
        query.addBindValue(ui->userLine->text());
        query.exec();
        if(query.next())
        {
            if (query.value(1).toString() == ui->passwordLine->text())
            {
                //创建工作人员登录窗口
                worker=new WorkerManage;
                worker->setWindowTitle(ui->userLine->text());
                worker->show();
                this->hide();
                return;
            }
            else
            {
                QMessageBox::warning(this, tr("账号密码错误"),
                                     tr("请输入正确的账号密码再登录！"), QMessageBox::Ok);
                ui->userLine->clear();
                ui->passwordLine->clear();
                ui->userLine->setFocus();
            }
        }
        else
            QMessageBox::information(this,tr("提示"),tr("没有此账号！"),QMessageBox::Ok);
    }
    //判断登录
    else if(radioGroup->checkedId()==2)
    {
        QSqlQuery query;
        query.prepare("select * from houseowner where ownername=?");
        query.addBindValue(ui->userLine->text());
        query.exec();
        if(query.next())
        {
            if (query.value(1).toString() == ui->passwordLine->text())
            {

                //创建业主登录窗口
                owner=new OwnerManage;
                owner->setWindowTitle(ui->userLine->text());
                owner->show();
                this->hide();
                return;
            }
            else
            {
                QMessageBox::warning(this, tr("账号密码错误"),
                                     tr("请输入正确的账号密码再登录！"), QMessageBox::Ok);
                ui->userLine->clear();
                ui->passwordLine->clear();
                ui->userLine->setFocus();
            }
        }
        else
            QMessageBox::information(this,tr("提示"),tr("没有此账号！"),QMessageBox::Ok);
    }
    else
        QMessageBox::warning(this,"警告","请选择登录方式",QMessageBox::Yes);
}

void LoginDialog::exitbtnSlot()
{
     this->close();
}

void LoginDialog::clearAll()
{
    ui->userLine->clear();
    ui->passwordLine->clear();
}

bool LoginDialog::judgeEmpty()
{
    if(ui->userLine->text().isEmpty())
    {
        QMessageBox::warning(this,"警告","用户名不能为空");
        return false;
    }
    if(ui->passwordLine->text().isEmpty())
    {
        QMessageBox::warning(this,"警告","密码不能为空");
        return false;
    }
    else
        return true;
}

