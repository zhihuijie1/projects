#ifndef CARSTATIONINFO_H
#define CARSTATIONINFO_H

#include <QWidget>
#include <QSqlTableModel>
#include <QMessageBox>
#include <QSqlRecord>
#include <QDebug>
#include <QButtonGroup>


namespace Ui {
class CarStationInfo;
}

class CarStationInfo : public QWidget
{
    Q_OBJECT

public:
    explicit CarStationInfo(QWidget *parent = 0);
    ~CarStationInfo();

private slots:
    void on_addCarStationConfirmBtn_clicked();

    void on_addCarStationReturnBtn_clicked();

private:
    Ui::CarStationInfo *ui;
    QSqlTableModel *carStationModel;
    QButtonGroup *typeRadioGroup;
    QButtonGroup *largeRadioGroup;
    QButtonGroup *electRadioGroup;
    QButtonGroup *rentRadioGRroup;
    QSqlTableModel *houseownerModel;

    bool judgeEmpty();
    void clearAll();

};

#endif // CARSTATIONINFO_H
