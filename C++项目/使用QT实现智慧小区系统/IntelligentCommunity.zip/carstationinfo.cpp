#include "carstationinfo.h"
#include "ui_carstationinfo.h"

CarStationInfo::CarStationInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CarStationInfo)
{
    ui->setupUi(this);

    typeRadioGroup=new QButtonGroup(this);
    typeRadioGroup->addButton(ui->carStationUpRadioBtn,0);
    typeRadioGroup->addButton(ui->carStationDownRadioBtn,1);
    ui->carStationUpRadioBtn->setChecked(true);

    largeRadioGroup=new QButtonGroup(this);
    largeRadioGroup->addButton(ui->carStationLargeRadioBtn,0);
    largeRadioGroup->addButton(ui->carStationSmallRadioBtn,1);
    ui->carStationLargeRadioBtn->setChecked(true);

    electRadioGroup=new QButtonGroup(this);
    electRadioGroup->addButton(ui->carStationEnableRadioBtn,0);
    electRadioGroup->addButton(ui->carStationDisableRadioBtn,1);
    ui->carStationDisableRadioBtn->setChecked(true);

    rentRadioGRroup=new QButtonGroup;
    rentRadioGRroup->addButton(ui->carStationWaitRentRadioBtn);
    rentRadioGRroup->addButton(ui->carStationRentedRadioBtn);
    ui->carStationWaitRentRadioBtn->setChecked(true);


    carStationModel=new QSqlTableModel(this);
    carStationModel->setTable("carstation");
    carStationModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    //carStationModel->removeColumns(5,5);/*?*/
    //connect(this,SIGNAL(EmitDataChanged()),,SLOT(refreshTableViewSlot()));


    houseownerModel=new QSqlTableModel(this);
    houseownerModel->setTable("houseowner");
    houseownerModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
}

CarStationInfo::~CarStationInfo()
{
    delete ui;
}

void CarStationInfo::on_addCarStationConfirmBtn_clicked()
{
    if(!this->judgeEmpty())
        return;
    carStationModel->select();
    houseownerModel->select();
    int i;
    for(i=0;i<carStationModel->rowCount();i++)
    {
        if(carStationModel->data(carStationModel->index(i,0)).toString()==ui->carStationNumLineEdit->text())
        {
            break;
        }
    }
    // -------------------------------------修改 -------------------------------------
    int j = 0;
    for(j=0;j<houseownerModel->rowCount();j++)
    {
        if(ui->carStationNumLineEditFlower->text() == houseownerModel->data(houseownerModel->index(j,0)).toString())
        {
            break;
        }
    }
    if(i!=carStationModel->rowCount())
    {
        QMessageBox::information(this,"提示","该车位信息已经存在",QMessageBox::Yes);
        this->clearAll();
        return;
    }

    // ---------------------------------------修改 ----------------------------------
    if(j==houseownerModel->rowCount())
    {
        QMessageBox::information(this,"提示","您还不是该小区业主，不可以选车位",QMessageBox::Yes);
        this->clearAll();
        return;
    }

    QSqlRecord record=carStationModel->record();
    record.setValue("carnum",ui->carStationNumLineEdit->text());
    record.setValue("type",typeRadioGroup->checkedId());
    record.setValue("large",largeRadioGroup->checkedId());
    record.setValue("electric",electRadioGroup->checkedId());
    // -------------------- 修改处-----------------------------------
    record.setValue("ownername",ui->carStationNumLineEditFlower->text());

    carStationModel->insertRecord(-1,record);
    if(carStationModel->submitAll())
    {
        QMessageBox::information(this,"提示","车位信息添加成功",QMessageBox::Yes);
        this->clearAll();
    }
}

void CarStationInfo::on_addCarStationReturnBtn_clicked()
{
    if(ui->carStationNumLineEdit->text().isEmpty())
    {
        //emit EmitWorkerChanged();
        this->hide();
        return;

    }
    if(QMessageBox::question(this,"提示","尚未保存，是否退出",QMessageBox::Yes|QMessageBox::No)==QMessageBox::Yes)
    {
        //emit EmitToTeacherManage();
        this->hide();
        carStationModel->select();
        //刷新tableview
    }
}

bool CarStationInfo::judgeEmpty()
{
    if(ui->carStationNumLineEdit->text().isEmpty()&&(typeRadioGroup->checkedId()==-1))
    {
        QMessageBox::warning(this,"警告","车位信息不能为空",QMessageBox::Yes);
        return false;
    }
    else
        return true;
}
void CarStationInfo::clearAll()
{
    ui->carStationNumLineEdit->clear();
}

