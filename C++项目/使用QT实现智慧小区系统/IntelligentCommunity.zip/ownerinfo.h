#ifndef OWNERINFO_H
#define OWNERINFO_H

#include <QWidget>
#include <QSqlTableModel>
#include <QMessageBox>
#include <QSqlRecord>
#include <QDebug>

namespace Ui {
class OwnerInfo;
}

class OwnerInfo : public QWidget
{
    Q_OBJECT

public:
    explicit OwnerInfo(QWidget *parent = 0);
    ~OwnerInfo();


private:
    Ui::OwnerInfo *ui;
     QSqlTableModel *model;

    bool judgeEmpty();
    void clearAll();




signals:
    void EmitWorkerChanged();
private slots:
    void on_ownerInfoConfirmBtn_clicked();
    void on_ownerInfoReturnBtn_clicked();
};

#endif // OWNERINFO_H
