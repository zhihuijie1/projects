#ifndef INITSYSTEM_H
#define INITSYSTEM_H

#include <QWidget>

namespace Ui {
class initSystem;
}

class initSystem : public QWidget
{
    Q_OBJECT

public:
    explicit initSystem(QWidget *parent = 0);
    ~initSystem();

private slots:
    void on_btnCarInit_clicked();

    void on_btnIssue_clicked();

    void on_btnPrice_clicked();

    void on_btnPriceRecord_clicked();

    void on_btnFree_clicked();

private:
    Ui::initSystem *ui;
};

#endif // INITSYSTEM_H
