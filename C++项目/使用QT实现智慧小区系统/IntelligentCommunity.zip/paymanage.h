#ifndef PAYMANAGE_H
#define PAYMANAGE_H

#include <QWidget>
#include <QSqlTableModel>
#include <QButtonGroup>
#include <QMessageBox>
#include <QSqlError>

namespace Ui {
class PayManage;
}

class PayManage : public QWidget
{
    Q_OBJECT

public:
    explicit PayManage(QWidget *parent = 0);
    ~PayManage();

private slots:
    void on_squreBtn_clicked();

    void on_payConfirmBtn_clicked();

    void on_pushButton_clicked();

private:
    Ui::PayManage *ui;
    QSqlTableModel *payModel;
    QButtonGroup *payStatusGroup;
};

#endif // PAYMANAGE_H
